# Quiz Game

Це гра-вікторина на JavaScript, зібрана за допомогою Webpack.

## Встановлення

1. Клонуйте репозиторій:

Встановіть залежності:
npm install
npm start
npm run build
